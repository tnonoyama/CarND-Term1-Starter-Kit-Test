
This is the caps sample with Äüö.
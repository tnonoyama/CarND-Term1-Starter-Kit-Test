if __name__ == '__main__':
    from qtconsole.qtconsoleapp import main
    main()

Qt-based console for Jupyter with support for rich media output


